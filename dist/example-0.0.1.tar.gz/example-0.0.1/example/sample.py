""" Command line tool """

import sys
from example import printcsv

def main():
    if len(sys.argv) != 2:
        exit("usage: ./sample file.csv")
    prints = printcsv.Prints(sys.argv[1])
    prints.printpairs()
