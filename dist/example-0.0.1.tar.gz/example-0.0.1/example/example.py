""" Acts as the interface between user and program """

import sys
from printcsv import Prints

def main():
    if len(sys.argv) != 2:
        exit("usage: ./sample file.csv")
    prints = Prints(sys.argv[1])
    prints.printpairs()

if __name__ == "__main__":
    main()
